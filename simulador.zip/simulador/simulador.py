#!/usr/bin/env python
# -*- coding: utf-8 -*-

import SimPy
from SimPy import *
from SimPy.Simulation import *
from random import *
from simulador import *
from config import *
import networkx as nx
import math
import time

from random import randrange
import numpy as np

from estatistica import Media, CalculaMediaDesvio

topology = nx.read_weighted_edgelist(TOPOLOGY, nodetype=int)

# Variaveis globais
no_regenerador = 0
validar_caminho = False         # verifica se existe um caminho valido origem-destino para uma requisicao

class Desalocate(Process):
        def __init__(self):
                SimPy.Simulation.Process.__init__(self)

        # Libera espectro apos o holding time    
        def Run(self,count,s_path,holding_time):
                global topology
                self.holding_time = holding_time 
                yield hold, self, self.holding_time

                ## Procurar indices.
                inicio = 0
                fim = 0
                flag = 0
                for slot in range(0,len(topology[s_path[0]][s_path[1]]['capacity'])): 
                        if topology[s_path[0]][s_path[1]]['capacity'][slot] == count:
                                if flag == 0:
                                        inicio = slot
                                        flag += 1
                                fim = slot
                for i in range(0, (len(s_path)-1)):
                        for slot in range(inicio,fim+1):
                                topology[s_path[i]][s_path[i+1]]['capacity'][slot] = 0
                                topology[s_path[i]][s_path[i+1]]['class_type'][slot] = 0
                        topology[s_path[i]][s_path[i+1]]['capacity'][fim+1] = 0
                        topology[s_path[i]][s_path[i+1]]['capacity'][fim+1] = 0

class Simulador(Process):
        NumReqBlocked = 0
        cont_req = 0
        NumReq = 0
        ListReg = 0
        TotalReg = 0

        def __init__(self):
                SimPy.Simulation.Process.__init__(self)
                global topology
                for u, v in topology.edges_iter():
                        topology[u][v]['capacity'] = [0] * SLOTS
                        topology[u][v]['class_type'] = [0] * SLOTS
                self.nodes = topology.nodes()
                self.edges = topology.edges()
                self.random = Random()

        def Run(self, rate):
                global topology
                global n_requisicao
                global validar_caminho
                
                edges = topology.number_of_edges()
                r = rate * topology.number_of_nodes()  
                Simulador.cont_req = 0
                Simulador.holding_time = 0
                cont = 0
                for count in xrange(1, NUM_OF_REQUESTS + 1):
                        yield hold, self, self.random.expovariate(r)            # Poisson
                        src, dst = self.random.sample(self.nodes, 2)            # requisicoes de origem - destino
                        dmd = self.random.choice(REQUESTS_DEMANDS)
                        data = self.random.choice(DATA)
                        s_path = self.CaminhoValido(topology, src, dst)
                        
                        Simulador.NumReq += 1
                        
                        if (validar_caminho == True):
                                distance = int(Simulador.Distance(self, s_path))

                                num_slots = int(math.ceil(Simulador.Modulation(self, distance, dmd)))
                                
                                if OPTION == '1':
                                        # verifica se possui spectro disponivel no caminho e se atende os parametros de restricao
                                        Simulador.check_path = Simulador.PathIsAble(self,num_slots,s_path)
                                        if (Simulador.check_path[0] == False):
                                        #if (validar_caminho == False):
                                                Simulador.NumReqBlocked += 1
                                        else:
                                                Simulador.cont_req += 1
                                                Simulador.FirstFit(self, count,Simulador.check_path[1],Simulador.check_path[2],s_path)
                                                Simulador.holding_time = Simulador.CalculaTempoTrans(self,dmd,data)
                                                #Libera espectro apos o holding time
                                                desalocate = Desalocate()
                                                SimPy.Simulation.activate(desalocate, desalocate.Run(count,s_path,Simulador.holding_time))
                                                
                        else:
                                Simulador.NumReqBlocked += 1
                
        # Adicionando regenerador OEO ao vertice
        def Add_regenerador(self, a):
                topology.add_nodes_from([a],regenerador='yes')
                regenerador=nx.get_node_attributes(topology ,'regenerador')
                return regenerador[a]


        # Seleciona o melhor menor caminho dentre o conjunto de caminhos validos
        def CaminhoValido(self, graph, inicio, fim):
                global topology
                global validar_caminho

                caminhos = list(self.dfs(inicio, fim))
                i = 0
                j = len(caminhos)
                fim = False
                validar_caminho = False
                while (i < j) or (fim == True):
                        if (self.Caminho(topology, caminhos[i]) == True):
                                validar_caminho = True
                                fim = True
                                return caminhos[i]
                        
                        elif (i >= j):
                                return caminhos[i]

                        i += 1
        
        # Verificar todos os caminhos possiveis
        def dfs(self, inicio, fim):
                global topology
                pilha = [(inicio, [inicio])]
                while pilha:
                        vertice, caminho = pilha.pop()
                        for proximo in set(topology[vertice]) - set(caminho):
                                if proximo == fim:
                                        yield caminho + [proximo]
                                else:
                                        pilha.append((proximo, caminho + [proximo]))
                                        
                
        # Validacao do caminho. Retorna se um certo caminho o - d e bloqueado ou nao
        def Caminho(self, graph, path): 
                global bloqueado
                global n_requisicao
                global nao_bloqueado
                global topology 
                global parametro_dist
                global parametro_salto
                global no_regenerador

                soma  = 0       
                salto = 0       
                block = 1
                for i in range(0, (len(path)-1)):               
                        soma = soma + topology[path[i]][path[i+1]]['weight']    #recebe peso da aresta entre i e i+1
                        salto= salto + 1                                        #incrementa o salto
                
                        if (soma > PARAMETRO_DISTANCIA) or (salto > PARAMETRO_SALTO):
                                return False
                
                        try:
                                if (topology.node[path[i+1]]['regenerador']) == ('yes'):        #verifica se existe regenerador no proximo vertice              
                                        Simulador.TotalReg += 1
                                        soma = 0                                                #se existe, zera os parametros e continua ate atingir o destino ou outro ponto de restauracao
                                        salto= 0
                        except Exception:
                                ""
                        
                return True

        # Estrategia de posicionamento da literatura NDF
        def Ndf(self, a):
                deg = nx.degree(topology)
                lista2 = deg.values()
                lista3 = sorted(deg)            
                n = topology.number_of_nodes()
                wow = np.zeros((n,2))

                for i in range(n):      
                        wow[i] = np.array([lista3[i],lista2[i]])        

                dt = [('col1', wow.dtype),('col2', wow.dtype)]
                aux = wow.ravel().view(dt)
                aux.sort(order=['col2','col1'])

                for i in range(a):
                        self.Add_regenerador(int(aux[::-1][i][0]))
                        
        
        # Estrategia de posicionamento proposta L-NDF
        def Lndf(self, a):
                deg = nx.degree(topology)
                lista2 = deg.values()
                lista3 = sorted(deg)
                vet = topology.degree(weight='weight')
                lista4 = vet.values()
                lista5 = sorted(vet)

                n = topology.number_of_nodes()
                wow = np.zeros((n,3))
                
                for i in range(n):      
                        wow[i] = np.array([lista5[i],lista2[i], lista4[i]])     

                dt = [('col1', wow.dtype),('col2', wow.dtype),('col3', wow.dtype)]
                aux = wow.ravel().view(dt)
                aux.sort(order=['col2','col3'])
                
                for i in range(a):
                        self.Add_regenerador(int(aux[::-1][i][0]))

        # Posicionamento de Regeneradores - topologia NSFnet HNF
        def Hnf(self, a):
                if a == 1:
                        self.Add_regenerador(5)
                        self.Add_regenerador(8)
                        self.Add_regenerador(13)
                        self.Add_regenerador(11)
                        self.Add_regenerador(7)
                        #self.Add_regenerador(5)
                        #self.Add_regenerador(9)
                        
        # Posicionamento de Regeneradores - topologia Abilene HNF
        def Lhnf(self, a):
                if a == 1:
                        self.Add_regenerador(1)
                        self.Add_regenerador(8)
                        self.Add_regenerador(7)
                        self.Add_regenerador(2)
                        self.Add_regenerador(9)
                        #self.Add_regenerador(0)
                        #self.Add_regenerador(3)

        # Calcula a distancia do caminho de acordo com os pesos das arestas               
        def Distance(self, path):
                global topology 
                soma = 0
                for i in range(0, (len(path)-1)):
                        soma += topology[path[i]][path[i+1]]['weight']
                return (soma)

        # Calcula o formato de modulacao de acordo com a distancia do caminho    
        def Modulation(self, dist, demand):
                if dist <= 500:
                        # 16-QAM
                        return (float(demand) / float(4 * SLOT_SIZE))
                elif 500 < dist <= 1000:
                        # 8-QAM
                        return (float(demand) / float(3 * SLOT_SIZE))
                elif 1000 < dist <= 2000:
                        # QPSK
                        return (float(demand) / float(2 * SLOT_SIZE)) 
                else:
                        # BPSK
                        return (float(demand) / float(1 * SLOT_SIZE))

        def FirstFit(self,count,i,j,path):
                global topology
                inicio = i 
                fim =j
                for i in range(0,len(path)-1):
                        for slot in range(inicio,fim):
                                #print slot
                                topology[path[i]][path[i+1]]['capacity'][slot] = count
                        topology[path[i]][path[i+1]]['capacity'][fim] = 'GB'

        # Calcula o tempo de transmissao de uma requisicao
        def CalculaTempoTrans(self,dmd,data):
                tempo = 0.0
                tempo = data/float(dmd)
                tempo2 = round(tempo, 1) 
                return  tempo2

        # Verifica se o caminho escolhido possui espectro disponivel para a demanda requisitada
        def PathIsAble(self, nslots,path):
                global topology
                cont = 0
                t = 0
                for slot in range (0,len(topology[path[0]][path[1]]['capacity'])):
                        if topology[path[0]][path[1]]['capacity'][slot] == 0:
                                k = 0
                                for ind in range(0,len(path)-1):
                                        if topology[path[ind]][path[ind+1]]['capacity'][slot] == 0:
                                                k += 1
                                if k == len(path)-1:
                                        cont += 1
                                        if cont == 1:
                                                i = slot
                                        if cont > nslots:
                                                j = slot
                                                return [True,i,j]
                                        if slot == len(topology[path[0]][path[1]]['capacity'])-1:
                                                        return [False,0,0]
                                else:
                                        cont = 0
                                        if slot == len(topology[path[0]][path[1]]['capacity'])-1:
                                                return [False,0,0]
                        else:
                                cont = 0
                                if slot == len(topology[path[0]][path[1]]['capacity'])-1:
                                        return [False,0,0]

        # Seleciona o melhor menor caminho dentre o conjunto de menores caminhos
        def SelectShortestPath(self, paths, dmd):
                global topology
                distance = []
                n_slots = float(dmd) / float(SLOT_SIZE)
                index = 0
                for path in paths:
                        if Simulador.PathIsAble(self, n_slots, path) == False:
                                paths.remove(path)
                if len(paths) == 0:
                        return paths

                else:
                        for p in paths:
                                distance.append(int(math.ceil(Simulador.Distance(self, p)))) 
                        menor = min(distance)
                        for pos, num in enumerate(distance):
                                if num == menor:
                                        indice = pos
                                return paths[index]
                        

def main(args):
        arquivo1 = open('bloqueio'+'.dat', 'w')
        for e in xrange(ERLANG_MIN, ERLANG_MAX+1, ERLANG_INC):
                Bloqueio = []

                for rep in xrange(10):
                        rate = e / HOLDING_TIME
                        seed(RANDOM_SEED)
                        SimPy.Simulation.initialize()
                        simulador = Simulador()
                        
                        # Estrategia de posicionamento
                        if ESTRATEGIA_POSICIONAMENTO == 'NDF':
                                simulador.Ndf(QTD_REG)
                        elif ESTRATEGIA_POSICIONAMENTO == 'LNDF':
                                simulador.Lndf(QTD_REG)
                        elif ESTRATEGIA_POSICIONAMENTO == 'HNF':
                                simulador.Hnf(1)
                        elif ESTRATEGIA_POSICIONAMENTO == 'LHNF':
                                simulador.Lhnf(1)                        

                        SimPy.Simulation.activate(simulador,simulador.Run(rate))
                        SimPy.Simulation.simulate(until=MAX_TIME)#MAX_TIME

                        #print rate
                        print "Erlang", e, "Simulacao...", rep

                        BloqueioTotal = float(Simulador.NumReqBlocked) / float(NUM_OF_REQUESTS)
                        Bloqueio.append(BloqueioTotal)
                result = CalculaMediaDesvio(Bloqueio)
                arquivo1.write(str(e))
                arquivo1.write("\t")
                arquivo1.write(str(result[0]))
                arquivo1.write("\t")
                arquivo1.write(str(result[0]-1.96*result[1]/math.sqrt(len(Bloqueio))))
                arquivo1.write("\t")
                arquivo1.write(str(result[0]+1.96*result[1]/math.sqrt(len(Bloqueio))))
                arquivo1.write("\n")
        
        print 'Qtd Requisicao: ' + str(simulador.NumReq)
        print 'Bloqueados: ' + str(simulador.NumReqBlocked)
        print 'Total Reg Usados: ' + str(simulador.TotalReg)

        arquivo1.close()
        return 0
if __name__ == '__main__':
        import sys
        sys.exit(main(sys.argv))
